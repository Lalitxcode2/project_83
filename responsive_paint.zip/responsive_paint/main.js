
var last_x, last_y;

    color = "blue";
    width_of_line = 2;

    canvas = document.getElementById('myCanvas');
    ctx = canvas.getContext("2d");

    var width = screen.width;

    new_width = screen.width - 70;
    new_height = screen.height- 200;
    if(width < 861)
    {
        document.getElementById("myCanvas").width = new_width; 
        document.getElementById("myCanvas").height = new_height; 
        document.body.style.overflow = "hidden";
    }

    canvas.addEventListener("touchstart", m_t_s);
    
    function m_t_s(e)
    {
        last_x = e.touches[0].clientX - canvas.offsetLeft;
         last_y = e.touches[0].clientY - canvas.offsetTop;

        
    }

    

    canvas.addEventListener("touchmove", t_m);
    function t_m(e)
    {

         current_position_of_mouse_x = e.touches[0].clientX - canvas.offsetLeft;
         current_position_of_mouse_y = e.touches[0].clientY - canvas.offsetTop;

        
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = width_of_line;

        console.log("Last position of x and y coordinates = ");
        console.log("x = " + last_x + "y = " + last_y);
        ctx.moveTo(last_x, last_y);

        console.log("Current position of x and y coordinates = ");
        console.log("x  = " + current_position_of_mouse_x + "y = " + current_position_of_mouse_y);
        ctx.lineTo(current_position_of_mouse_x, current_position_of_mouse_y);
        ctx.stroke();
        


        last_x = current_position_of_mouse_x; 
        last_y = current_position_of_mouse_y;
    }

